﻿--add a new column
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=object_id('[FNS_IPFilter_IPNetwork]') and NAME='StoreId')
BEGIN
	ALTER TABLE [FNS_IPFilter_IPNetwork]
	ADD [StoreId] int NOT NULL CONSTRAINT DF_FNS_IPFilter_IPNetwork_StoreId DEFAULT 0
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=object_id('[FNS_IPFilter_IP]') and NAME='StoreId')
BEGIN
	ALTER TABLE [FNS_IPFilter_IP]
	ADD [StoreId] int NOT NULL CONSTRAINT DF_FNS_IPFilter_IP_StoreId DEFAULT 0
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=object_id('[FNS_IPFilter_Country]') and NAME='StoreId')
BEGIN
	ALTER TABLE [FNS_IPFilter_Country]
	ADD [StoreId] int NOT NULL CONSTRAINT DF_FNS_IPFilter_Country_StoreId DEFAULT 0
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=object_id('[FNS_IPFilter_IP]') and NAME='Comment')
BEGIN
	ALTER TABLE [FNS_IPFilter_IP] ADD [Comment] varchar(200) NULL
	ALTER TABLE [FNS_IPFilter_IP] ALTER COLUMN [IpAddress] varchar(39) NOT NULL
END
GO
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id=object_id('[FNS_IPFilter_IPNetwork]') and NAME='IpAddressFrom' and max_length<39)
BEGIN
	ALTER TABLE [FNS_IPFilter_IPNetwork] ALTER COLUMN [Comment] varchar(200) NULL
	ALTER TABLE [FNS_IPFilter_IPNetwork] ALTER COLUMN [IpAddressFrom] varchar(39) NOT NULL
	ALTER TABLE [FNS_IPFilter_IPNetwork] ALTER COLUMN [IpAddressTo] varchar(39) NOT NULL
END
GO


